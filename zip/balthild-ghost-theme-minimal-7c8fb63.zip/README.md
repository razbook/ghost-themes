# Minimal Theme for Ghost

[Minimal](https://github.com/orderedlist/minimal) is a plain HTML template originally. [Demo](http://orderedlist.github.com/minimal/)

In addition to porting it to Ghost, I've replaced floating layout with CSS3 flexbox, which drops the support for outdated browsers.
