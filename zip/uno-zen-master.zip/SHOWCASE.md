## Showcase

<div align="center">
<a target="blank" href="https://kikobeats.com"><img src="http://i.imgur.com/crE8jt2.png"></a>
<a target="blank" href="https://www.evilsocket.net/"><img src="http://i.imgur.com/qanAbQf.png"></a>
<a target="blank" href="https://www.pupboss.com/"><img src="http://i.imgur.com/0AeVKgB.png"></a>
<a target="blank" href="http://www.flaviocorpa.com"><img src="http://i.imgur.com/1ESq2xs.png" /></a>
<a target="blank" href="http://morris.guru"><img src="http://i.imgur.com/s9oimfG.png" /></a>
<a target="blank" href="https://adrianperez.org"><img src="http://i.imgur.com/XlNFWWA.png" /></a>
<a target="blank" href="http://www.bradenericson.com"><img src="http://i.imgur.com/8wz0LKN.png" /></a>
<a target="blank" href="https://robinz.in"><img src="http://i.imgur.com/qDAbrch.jpg" /></a>
<a target="blank" href="http://biercoff.com"><img src="http://i.imgur.com/goS3pE3.jpg" /></a>
<a target="blank" href="https://randy.sesser.me"><img src="http://i.imgur.com/9hacUJc.jpg" /></a>
<a target="blank" href="http://maptime.io/milan/"><img src="http://i.imgur.com/hd9tpzq.jpg" /></a>
<a target="blank" href="http://xlbd.me"><img src="http://i.imgur.com/wiqVB9R.jpg" /></a>
<a target="blank" href="http://olddonkey.com"><img src="http://i.imgur.com/wa4kwnZ.jpg" /></a>
<a target="blank" href="http://www.mohammedovich.com/"><img src="http://i.imgur.com/oiKFBG2.jpg" /></a>
<a target="blank" href="http://yangshuan.cn"><img src="http://i.imgur.com/6ptrCIp.jpg" /></a>
<a target="blank" href="http://4ts.io"><img src="http://i.imgur.com/wm9Lr5o.png" /></a>
<a target="blank" href="http://binaryfever.com"><img src="http://i.imgur.com/SHzfMEE.png" /></a>
<a target="blank" href="http://joshmiramant.com"><img src="http://i.imgur.com/JnDzgLq.gif"></a>
</br>
</br>
</div>

## Add your blog

1. Customize your blog! Use a different color and combine it with a nice background.
2. Take a snapshot of your blog in the main page.
2. Trim the snapshot to remove top and bottom margins and resize it into  **327 × 174 pixels**.
3. Host the snapshot in a image hosting like [imgur](https://imgur.com).
4. Edit this file adding a new line at the end of this file following the format:

```html
<a target="blank" href="https://kikobeats.com"><img src="http://i.imgur.com/crE8jt2.png"></a>
```

5. Create a Pull Request!


