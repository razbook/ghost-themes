**Warning:** No longer using or updating this, as I'm not using Ghost any more.

# crisp-narrow
Ghost theme built on [crisp](https://github.com/kathyqian/crisp) with a lot of tweaks. I use it with [buster](https://github.com/carderne/buster) to publish my blog on GitHub Pages. Social Icons from [here](http://www.socicon.com/chart.php) and some stylistic cues from [gergelyorosz/GhostSocialCasper](https://github.com/gergelyorosz/GhostSocialCasper) 

Compatible with Ghost v2.2+

I'm currently using it on my personal blog: https://rdrn.me/
