# pharos
yuanliang.io's theme for ghost. (Based on Journal Ghost theme)

Pharos Ghost theme is licensed under the General Public
License (MIT).

```bash
npm install -g less@2.7.2 less-plugin-clean-css
npm style
npm clean
```

Modify in July 2016. by Yuan Liang (yuanliang@me.com)
Thanks Stefan Djokic(djokics@elfak.rs) for Developed Journal Ghost theme in July 2015.