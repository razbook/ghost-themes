# Aquila

A very clean, minimalist theme for Ghost. There is a classic and a modern version.

## Modern

Demo: [My blog](http://blog.lxnd.me/)

![Screenshot](https://abload.de/img/aquila-modernw7j5p.png)

## Classic

![Screenshot](http://sc.korn-online.org/021114114153.png)
