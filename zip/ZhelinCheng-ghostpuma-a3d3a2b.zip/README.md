# ghostpuma

## 主题说明

Ghost主题ghostpuma，设计来自wordpress主题[Puma](https://github.com/bigfa/Puma)。

目前该主题做为自用，主题模板中含有个人网站备案信息等（如若有好的解决方案，请PR），后期随着Ghost升级会移除。

如若现在使用该主题，请自行Fork修改。

## 版本说明

------------------------------
Ghostpuma Version 1.0.0
------------------------------

- 完成基本功能