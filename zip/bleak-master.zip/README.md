**[Find out more at unwitting.github.io/bleak](http://unwitting.github.io/bleak)**

[![bleak](http://i.imgur.com/MJQUkXL.png)](http://unwitting.github.io/bleak)

# bleak. a theme for ghost [![gtca button](https://img.shields.io/badge/configured%20with-GTCA-brightgreen.svg)](https://github.com/unwitting/gtca)

__bleak__ is a stunning theme for the [Ghost](https://ghost.org/) blog platform. It features
full-section images and a slick responsive design that puts the right content right in your
readers' faces.

**[Find out more at unwitting.github.io/bleak](http://unwitting.github.io/bleak)**
