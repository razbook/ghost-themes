# folio
An open-source ghost theme

example: [check out my personal blog running Folio](https://walkerfrederick.com)


## What is Folio?
Folio is an open-source ghost theme that can be used for you're personal blog. I personally use it as my own personal site/portfolio.

If you are interested in contributing i'd love the help...please check to TODO section at the bottom of this readme.


## Key Features
1. Folio has built in the abillity to seperate any projects away from other blog posts.
2. Built in contact page, making it great for a personal site.
3. Easily change colors to match you're personal brand...coming soon

## ToDo
1. remove all 'me' specific content
2. general favicon design!
3. add 'logo' support
